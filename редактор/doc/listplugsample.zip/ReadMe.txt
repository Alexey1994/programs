This is a sample lister plugin to show c and Pascal files
with line numbers.

This plugin is freeware. You may use this source code to
write your own plugin (free or commercial).

Author:
Christian Ghisler, support@ghisler.com
